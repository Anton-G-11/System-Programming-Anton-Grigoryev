#ifndef TEST4_H
#define TEST4_H


class test4
{
public:
    test4();
};

#endif // TEST4_H
